/**
 */
package webapp;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>File</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see webapp.WebappPackage#getFile()
 * @model
 * @generated
 */
public interface File extends EObject {
} // File
