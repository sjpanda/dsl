/**
 */
package webapp;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Properties</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see webapp.WebappPackage#getProperties()
 * @model
 * @generated
 */
public interface Properties extends EObject {
} // Properties
