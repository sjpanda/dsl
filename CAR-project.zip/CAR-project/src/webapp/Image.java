/**
 */
package webapp;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Image</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see webapp.WebappPackage#getImage()
 * @model
 * @generated
 */
public interface Image extends EObject {
} // Image
