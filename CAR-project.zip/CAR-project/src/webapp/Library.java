/**
 */
package webapp;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Library</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see webapp.WebappPackage#getLibrary()
 * @model
 * @generated
 */
public interface Library extends EObject {
} // Library
