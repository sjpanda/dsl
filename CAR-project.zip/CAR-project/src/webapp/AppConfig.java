/**
 */
package webapp;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>App Config</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see webapp.WebappPackage#getAppConfig()
 * @model
 * @generated
 */
public interface AppConfig extends EObject {
} // AppConfig
